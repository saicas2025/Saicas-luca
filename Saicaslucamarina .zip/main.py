from flask import Flask, request, jsonify
import fitz  # PyMuPDF
from PIL import Image
import io, base64, os
from openai import OpenAI

app = Flask(__name__)

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def extract_text_from_pdf(file_bytes):
    pdf = fitz.open(stream=file_bytes, filetype="pdf")
    text = ""
    for page in pdf:
        text += page.get_text()
    return text.strip()

def image_to_base64(img_bytes):
    return base64.b64encode(img_bytes).decode("utf-8")

@app.route("/extract", methods=["POST"])
def extract():
    if "file" not in request.files:
        return jsonify({"error": "Nessun file caricato"}), 400
    file = request.files["file"]
    file_bytes = file.read()
    text_content = ""

    if file.filename.lower().endswith(".pdf"):
        try:
            text_content = extract_text_from_pdf(file_bytes)
        except Exception as e:
            return jsonify({"error": f"Errore PDF: {str(e)}"}), 500
    else:
        img_b64 = image_to_base64(file_bytes)
        prompt = "Leggi attentamente questo disegno tecnico e prepara un preventivo dettagliato con peso, lavorazioni e costo finale."
        try:
            resp = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Sei un esperto di preventivi per lavorazioni metalliche."},
                    {"role": "user", "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}}
                    ]}
                ],
                max_tokens=500
            )
            text_content = resp.choices[0].message.content
        except Exception as e:
            return jsonify({"error": f"Errore AI: {str(e)}"}), 500

    return jsonify({"text": text_content})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
